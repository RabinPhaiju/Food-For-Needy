function SocialMedia1(){
    var s=document.querySelector('.innerBtn');
    s.style.display = 'block';
    document.querySelector('#btn2').style.display ='none';
    document.querySelector('#btn3').style.display ='block';
}
function SocialMedia2(){
    var s=document.querySelector('.innerBtn');
    s.style.display = 'none';
    document.querySelector('#btn3').style.display ='none';
    document.querySelector('#btn2').style.display ='block';
}

